const config = {
    chain: 'http://121.196.200.225:1337',
    // privateKey: 'a3b33668e5be5b31e08f5695a1efb21bd0c2e8607d06a5b55021585883be93ac',
    // privateKey: '5d656090779d8dc7a33cfc59891ebe2794557f438fa72c9994fe238652d78bbd',
    // from : '0x9728aA04922A11Db65E54ED499727666672339b5',

    contractAddress: '0x800C88D4151A58B0B141d13aC4C448991C9BA543',

    apiAddress:'http://58.87.125.190:9999',

    pc_media: "(min-width:31em)",
}

module.exports = config
